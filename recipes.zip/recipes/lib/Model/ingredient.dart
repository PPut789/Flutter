class Ingredient {
  String name;
  int quantity;
  String unit;
  List<Ingredient> Ingredients = [];
  
  Ingredient({
    required this.name, 
    required this.quantity, 
    required this.unit});
}

