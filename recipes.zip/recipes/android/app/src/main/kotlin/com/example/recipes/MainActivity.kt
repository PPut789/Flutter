package com.example.recipes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
